<?php
header("Content-Type: text/html;charset=utf-8");
date_default_timezone_set('Asia/Shanghai');

$account 	= 'XXXXXXXX';//8位account
$api_key 	= 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'; //32位api_key
$timeStamp 	= time();

//提交订单
$submiturl = 'http://121.41.8.25:8081/Submit.php';

$phone 		= '136xxxx1234'; //手机号
$range 		= 0; //0全国
$size 		= 150; //单位 M

$pd = array(
		'account'	=> $account,
		'action'	=> 'Charge',
		'phone'		=> $phone,
		'range'		=> $range,
		'size'		=> $size,
		'timeStamp'	=> $timeStamp,
);
$pre_str = "{$api_key}account={$account}&action=Charge&phone={$phone}&range={$range}&size={$size}&timeStamp={$timeStamp}{$api_key}";
$pd['sign'] = md5($pre_str);

$rt = https_request($submiturl, $pd);
$ret = json_decode($rt, true);
var_dump($pd);echo '<hr />';
var_dump($rt);echo '<hr />';
var_dump($ret);


//查询订单
/* 
$queryurl = 'http://121.41.8.25:8081/Query.php';
$qd = array(
		'account'	=> $account,
		'action'	=> 'Query',
		'orderID'	=> '1370708624514587914360236',
		'timeStamp'	=> $timeStamp,
);
$p_str = "{$api_key}account={$account}&action=Query&orderID={$qd['orderID']}&timeStamp={$timeStamp}{$api_key}";
$qd['sign'] = md5($p_str);
$rt = https_request($queryurl, $qd);
$ret = json_decode($rt, true);
var_dump($qd);echo '<hr />';
var_dump($rt);echo '<hr />';
var_dump($ret); 
*/

//查询余额
/*
$balance_url = 'http://121.41.8.25:8081/Balance.php';
$bd = array(
		'account'	=> $account,
		'action'	=> 'Balance',
		'timeStamp'	=> $timeStamp,
);
$bd['sign'] = md5("{$api_key}account={$account}&action=Balance&timeStamp={$timeStamp}{$api_key}");
$rt = https_request($balance_url, $bd);
$ret = json_decode($rt, true);
var_dump($bd);echo '<hr />';
var_dump($rt);echo '<hr />';
var_dump($ret);
*/


/** http请求（支持GET和POST） */
function https_request($url, $data = null) {
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	if (!empty($data)) {
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	}
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($curl);
	curl_close($curl);
	return $output;
}



?>